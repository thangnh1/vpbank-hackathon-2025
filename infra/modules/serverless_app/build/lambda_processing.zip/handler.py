import json

def lambda_handler(event, context):
    records = event.get("Records", []) if isinstance(event, dict) else []
    return {
        "statusCode": 200,
        "body": json.dumps({"processed_records": len(records)}),
    }
