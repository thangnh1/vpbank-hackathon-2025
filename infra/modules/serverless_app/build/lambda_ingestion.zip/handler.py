import json

def lambda_handler(event, context):
    message = event.get("body") if isinstance(event, dict) else str(event)
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "ingestion stub", "payload": message}),
    }
