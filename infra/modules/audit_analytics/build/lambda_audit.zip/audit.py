import boto3
import os
import json
from datetime import datetime

s3 = boto3.client("s3")
bucket = os.environ.get("AUDIT_BUCKET")

def lambda_handler(event, context):
    timestamp = datetime.utcnow().isoformat()
    payload = json.dumps({"timestamp": timestamp, "event": event}, default=str)
    key = f"year={timestamp[:4]}/month={timestamp[5:7]}/logs-{timestamp}.json"
    s3.put_object(Bucket=bucket, Key=key, Body=payload.encode("utf-8"))
    return {"statusCode": 200, "body": json.dumps({"stored": key})}
